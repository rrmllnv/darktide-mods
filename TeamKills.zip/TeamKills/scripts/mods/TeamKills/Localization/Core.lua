return {
	i18n_mod_title = {
		en = "Team Kills",
		ru = "Командные убийства",
	},
	i18n_mod_description = {
		en = "TeamKills - Comprehensive mod for real-time team statistics tracking: kills, damage, killstreaks by enemy categories with detailed stats board and boss notifications.",
		ru = "TeamKills - Комплексный мод для отслеживания статистики команды в реальном времени: убийства, урон, серии убийств по категориям врагов с детальной доской статистики и уведомлениями о боссах.",
	},
}
